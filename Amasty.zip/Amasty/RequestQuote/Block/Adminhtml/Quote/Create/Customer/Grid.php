<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2020 Amasty (https://www.amasty.com)
 * @package Amasty_RequestQuote
 */


namespace Amasty\RequestQuote\Block\Adminhtml\Quote\Create\Customer;

class Grid extends \Magento\Backend\Block\Widget\Grid
{
    /**
     * @inheritdoc
     */
    public function toHtml()
    {
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$customerSession = $objectManager->create('Magento\Customer\Model\Session');
        $html = parent::toHtml();
        $html = preg_replace(
            '@require\(deps@s',
            'deps.push(\'jquery\');deps.push(\'Amasty_RequestQuote/quote/create/form\');$0',
            $html,
            1
        );
		if($customerSession->getCustomerDynamic()!='') {
			$html.='<style>';
			$html.='table tbody tr:nth-child(1) {border : 2px solid #cccccc !important;}
';
			$html.='</style>';
			$html.='<script>';
			$html.='require([
					"jquery"
					], function($){
					$(document).ready(function () {';
					$html.='$("#sales_order_create_customer_grid_filter_email").val("'.$customerSession->getCustomerDynamic().'");';					
			$html.='});
			});';
			$html.='</script>';
			$html.='';
			$customerSession->unsCustomerDynamic();
		}
        return $html;
    }
}
