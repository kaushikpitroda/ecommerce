<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2019 Amasty (https://www.amasty.com)
 * @package Amasty_Promo
 */


namespace Amasty\Promo\Helper;

/**
 * @deprecated use \Amasty\Promo\Model\Config instead.
 */
class Config extends \Amasty\Promo\Model\Config
{

}
