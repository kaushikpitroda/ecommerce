<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2019 Amasty (https://www.amasty.com)
 * @package Amasty_Conditions
 */


namespace Amasty\Conditions\Model;

class Constants
{
    const VALUE_SELECT_OPTIONS = 'value_select_options';

    const MODULE_NAME = 'Advanced Conditions';
}
